﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Room
{
    public interface ISink
    {
        string Wash(Soap soap);

    }
}
