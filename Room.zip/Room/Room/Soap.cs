﻿namespace Room
{
    public class Soap
    {
        public string Name { get; set; }

        public Soap(string name)
        {
            Name = name;
        }

    }
}