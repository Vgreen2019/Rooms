﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Room
{
    interface IOven
    {
        string Bake(Pot pot, int temp);


    }
}
