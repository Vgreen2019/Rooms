﻿namespace Room
{
    public class Clothes
    {
        public string Name { get; set; }

        public Clothes(string name)
        {
            Name = name;
        }

    }

}