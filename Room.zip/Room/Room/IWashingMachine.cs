﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Room
{
    interface IWashingMachine
    {
        void WashClothes(List<Clothes> clothes);

    }
}
