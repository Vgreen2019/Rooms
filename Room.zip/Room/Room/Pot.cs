﻿namespace Room
{
    public class Pot
    {
        public string Name { get; set; }

        public Pot(string name)
        {
            Name = name;
        }
    }
}