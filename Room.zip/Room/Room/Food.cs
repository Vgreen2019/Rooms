﻿namespace Room
{
    public class Food
    {
        public string Name { get; set; }

        public Food(string name)
        {
            Name = name;
        }

    }
}